package com.cg.nsa.service;

import com.cg.nsa.entity.User;
import com.cg.nsa.repository.IUserRepositoryImpl;

public class IUserServiceImpl implements IUserService {
	IUserRepositoryImpl repository = new IUserRepositoryImpl();

	@Override
	public User login(User user) {

		return repository.login(user);
	}

	@Override
	public User logout(User user) {

		return repository.logout(user);
	}

}

package com.cg.nsa.service;

import java.util.List;

import com.cg.nsa.entity.Institution;
import com.cg.nsa.exception.InvalidInstitutionException;
import com.cg.nsa.repository.IInstituteRepositoryImpl;

public class IInstituteServiceImpl implements IInstituteService {
	IInstituteRepositoryImpl repository = new IInstituteRepositoryImpl();

	@Override
	public Institution addInstitute(Institution institute) {

		return repository.saveInstitute(institute);
	}

	@Override
	public Institution editInstitute(Institution institute) {

		return repository.updateInstitute(institute);
	}

	@Override
	public Institution statusUpdate(Institution institute) {

		return repository.statusUpdate(institute);
	}

	@Override
	public Institution getInstitute(int code) throws InvalidInstitutionException {

		return repository.fetchInstitute(code);
	}

	@Override
	public List<Institution> getAllInstitutes() {

		return repository.fetchAllInstitutes();
	}

	@Override
	public List<Institution> getInstitutesByState(String state) {

		return repository.fetchInstitutesByState(state);
	}

}

package com.cg.nsa.service;

import java.util.List;

import com.cg.nsa.entity.Scholarship;
import com.cg.nsa.repository.IScholarshipRepositoryImpl;

public class IScholarshipServiceImpl implements IScholarshipService {
	IScholarshipRepositoryImpl repository = new IScholarshipRepositoryImpl();

	@Override
	public Scholarship statusUpdate(Scholarship scholarship) {

		return repository.statusUpdate(scholarship);
	}

	@Override
	public List<Scholarship> getAllScholarships() {

		return repository.fetchAllScholarships();
	}

}

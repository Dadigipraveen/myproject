package com.cg.nsa.service;

import java.util.List;

import com.cg.nsa.entity.Scholarship;
import com.cg.nsa.entity.Student;
import com.cg.nsa.exception.InvalidInstitutionException;
import com.cg.nsa.repository.IStudentRepositoryImpl;

public class IStudentServiceImpl implements IStudentService {
	IStudentRepositoryImpl repository = new IStudentRepositoryImpl();

	@Override
	public Student addStudent(Student student) {

		return repository.updateStudent(student);
	}

	@Override
	public Student editStudent(Student student) {

		return repository.updateStudent(student);
	}

	@Override
	public List<Student> getAllStudents() {

		return repository.fetchAllStudents();
	}

	@Override
	public List<Student> getStudentsByInstitute(String name) throws InvalidInstitutionException {

		return repository.fetchAllStudents();
	}

	@Override
	public char[] getAccountDetails(Scholarship scholarship) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public char[] updateScholarship(Scholarship scholarship) {
		// TODO Auto-generated method stub
		return null;
	}

}

package com.cg.nsa.service;

import java.util.List;

import com.cg.nsa.entity.Officer;
import com.cg.nsa.repository.IOfficerRepositoryImpl;

public class IOfficerServiceImpl implements IOfficerService {
	IOfficerRepositoryImpl repository = new IOfficerRepositoryImpl();

	@Override
	public Officer addOfficer(Officer officer) {

		return repository.saveOfficer(officer);
	}

	@Override
	public Officer editOfficer(Officer officer) {

		return repository.updateOfficer(officer);
	}

	@Override
	public Officer getOfficerByState(String state) {

		return repository.fetchOfficerByState(state);
	}

	@Override
	public List<Officer> getAllOfficers() {

		return repository.fetchAllOfficers();
	}

}

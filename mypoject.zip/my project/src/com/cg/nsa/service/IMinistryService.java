package com.cg.nsa.service;

import com.cg.nsa.entity.Scholarship;

public interface IMinistryService {
	
	Scholarship grant(Scholarship scholarship);
}

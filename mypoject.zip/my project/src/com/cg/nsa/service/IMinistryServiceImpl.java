package com.cg.nsa.service;

import com.cg.nsa.entity.Scholarship;
import com.cg.nsa.repository.IMinistryRepositoryImpl;

public class IMinistryServiceImpl implements IMinistryService {
	IMinistryRepositoryImpl repository = new IMinistryRepositoryImpl();

	@Override
	public Scholarship grant(Scholarship scholarship) {

		return repository.grant(scholarship);
	}

}

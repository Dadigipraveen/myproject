package com.cg.nsa.ui;

import java.time.LocalDate;
import java.util.Scanner;

import com.cg.nsa.entity.Scholarship;
import com.cg.nsa.service.IStudentService;
import com.cg.nsa.service.IStudentServiceImpl;

public class client {
	
	public static void main(String[] args) {
		int studentId;
		String fullName;
		String birthdate;
		String gender;
		long mobileNo = 0;
		String email;
		String address;
		String city;
	    IStudentService service= new IStudentServiceImpl();
		
			Scanner sc = new Scanner(System.in);
			System.out.println("***** Student Scholarship *********");
			while(true){
				System.out.println("1.Create Scholarship Application");
				System.out.println("2.Display Schlorship Application");
				System.out.println("3.Update schloarship Application");
				System.out.println("4.check status of Application");
				int option = sc.nextInt();
				switch (option) {
				
				case 1:
					System.out.println("Enter Student id");
					studentId = sc.nextInt();
					System.out.println("Enter Student FullName");
					fullName = sc.next();
					System.out.println("Enter Student Birthdate");
					birthdate = sc.next();
					System.out.println("Enter Student Gender");
					gender = sc.next();
					System.out.println("Enter Student Address");
					address = sc.next();
					System.out.println("Enter student Email");
					email = sc.next();
					System.out.println("Enter Student Mobile Number ");
					sc.nextLong();
					
					Scholarship Scho = new Scholarship(studentId,fullName,birthdate,gender,address,email,mobileNo);
					
					System.out.println("your  student scholarship  successfully created" +Scho);
					
					break;
						
	   case 2:
		   System.out.println("Enter the Account Details:");
			  sc.next();
			System.out.println(service.getAccountDetails(Scho));	
					
					break;
	   case 3:
		   System.out.println("Enter Student id to update");
			studentId = sc.nextInt();
			System.out.println(service.updateScholarship(Scho));
		
		break;
				
				}
			}	
	}

}

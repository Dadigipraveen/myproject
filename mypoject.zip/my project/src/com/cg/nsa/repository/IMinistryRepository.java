package com.cg.nsa.repository;

import com.cg.nsa.entity.Scholarship;

public interface IMinistryRepository {
	
	Scholarship grant(Scholarship scholarship);
}

package com.cg.nsa.repository;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;

import com.cg.nsa.entity.Officer;

public class IOfficerRepositoryImpl implements IOfficerRepository {
	HashMap<Integer, Officer> Officers = new HashMap<>();
	private List<Officer> Officer;

	@Override
	public Officer saveOfficer(Officer officer) {
		int OfficerName = Officer.getOfficerDetails();
		Officer.put(Officerdetails, Officer);
		return Officers;
	}

	@Override
	public Officer updateOfficer(Officer officer) {
		int Officerdetails = Officer.getOfficerDetails();
		Officer.update(Officerdetails, Officer);
		return Officers;

		return "Officer Details updated";
	}

	@Override
	public Officer fetchOfficerByState(String state) {
		Officer.fetch(Officers,state)
		
		return "Officer details fetched";
	}

	@Override
	public List<Officer> fetchAllOfficers() {
		Set<Entry<Integer, Officer>> Offs = Officers.entrySet();
		Iterator<Entry<Integer, Officer>> itr = Offs.iterator();
		ArrayList<Officer> products1 = new ArrayList<Officer>();
		while (itr.hasNext()) {
			Entry<Integer, Officer> entries = itr.next();
			Officer.add(entries.getValue());
			return Officer;
		}

	}
}

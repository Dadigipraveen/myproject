package com.cg.nsa.repository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;

import com.cg.nsa.entity.Scholarship;

public class IScholarshipRepositoryImpl implements IScholarshipRepository {
	HashMap<Integer, Scholarship> Scholarships = new HashMap<>();

	@Override
	public Scholarship statusUpdate(Scholarship scholarship) {
		Scholarship = Scholarship.getScholarshipId();
		Scholarship.update(Scholarshipid, Scholarship);

		return updatedScholarshipid;
	}

	@Override
	public List<Scholarship> fetchAllScholarships() {
		Set<Entry<Integer, Scholarship>> Scholars = Scholarships.entrySet();
		Iterator<Entry<Integer, Scholarship>> itr = Scholars.iterator();
		ArrayList<Scholarship> Scholarships1 = new ArrayList<Scholarship>();
		while (itr.hasNext()) {
			Entry<Integer, Scholarship> entries = itr.next();
			Scholarships1.add(entries.getValue());

			return Scholarships1;
		}

	}
}

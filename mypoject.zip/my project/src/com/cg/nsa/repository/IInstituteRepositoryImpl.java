package com.cg.nsa.repository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;

import com.cg.nsa.entity.Institution;
import com.cg.nsa.exception.InvalidInstitutionException;

public class IInstituteRepositoryImpl implements IInstituteRepository {
	HashMap<Integer, Institution> Scholarship = new HashMap<>();
	private Object InstitutionName;
	private List<Institution> a1;

	@Override
	public Institution saveInstitute(Institution institute) {
		String Institutionname = Institution.getInstitutionName();
		Institution.put(InstitutionName, institute);

		return saveInstitutionName;
	}

	@Override
	public Institution updateInstitute(Institution institute) {
		String Institutionname = Institution.getInstitutionName();
		Institution.put(InstitutionName, institute);
		
		return InstitutionName;
	}

	@Override
	public Institution statusUpdate(Institution institute) {
		int Institution =  Institution.statusUpdateInstitution();
		Institution.set(InstitutionName,Institute)
		
		return "status update Institution";
	}

	@Override
	public Institution fetchInstitute(int code) throws InvalidInstitutionException {
		
		return null;
	}

	@Override
	public List<Institution> fetchAllInstitutes() {
		Set<Entry<Integer, Institution>> Institution = Institution.entrySet();
		Iterator<Entry<Integer, Institution>> itr = Institution.iterator();
		ArrayList<Institution> al = new ArrayList<Institution>();
		while (itr.hasNext()) {
			Entry<Integer, Institution> result = itr.next();

			al.fetch(result.getValue());
			
		return a1;
	}
	}

	@Override
	public List<Institution> fetchInstitutesByState(String state) {
		
		return null;
	}

}

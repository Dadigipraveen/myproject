package com.cg.nsa.repository;

import java.util.HashMap;

import com.cg.nsa.entity.User;

public class IUserRepositoryImpl implements IUserRepository {
	HashMap<Integer, User> Users = new HashMap<>();

	@Override
	public User login(User user) {
		User login = User.getUserId();

		return login(user);
	}

	@Override
	public User logout(User user) {
		User logout = User.getUserId();

		return logout(user);
	}

}

package com.cg.nsa.repository;

import java.util.HashMap;

import com.cg.nsa.entity.Ministry;
import com.cg.nsa.entity.Scholarship;

public class IMinistryRepositoryImpl implements IMinistryRepository {
	HashMap<Integer, Ministry> Ministry = new HashMap<>();

	@Override
	public Scholarship grant(Scholarship scholarship) {
		 Ministry = Ministry.getMinistry();
		 Ministry.grant(scholarship);
		

		return " MInistryRepo";
	}

}

package com.cg.nsa.repository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;

import com.cg.nsa.entity.Student;
import com.cg.nsa.exception.InvalidInstitutionException;

public class IStudentRepositoryImpl implements IStudentRepository {
	HashMap<Integer, Student> students = new HashMap<>();

	@Override
	public Student saveStudent(Student student) {
		int Studentcode = student.getStudentId();
		students.put(Studentcode,student);
		
		return "Save Studentcode ";
	}
	

	@Override
	public Student updateStudent(Student student) {
		int studentcode = student.getstudentcode();
		students.put(studentcode, student);

		return "studentcode updated successfully;
	}

	@Override
	public List<Student> fetchAllStudents() {
		Set<Entry<Integer, Student>> pros = Student.entrySet();
		Iterator<Entry<Integer, Student>> itr = pros.iterator();
		ArrayList<Student> Students1 = new ArrayList<Student>();
		while (itr.hasNext()) {
			Entry<Integer, Student> entries = itr.next();
			Students1.add(entries.getValue());

			return Students1;
		}
	}

	@Override
	public List<Student> fetchStudentsByInstitute(String name) throws InvalidInstitutionException {

		return null;
	}

}

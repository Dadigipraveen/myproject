package com.cg.nsa.entity;

public class Ministry extends User {
	String portfolio;

	public String getPortfolio() {
		return portfolio;
	}

	public void setPortfolio(String portfolio) {
		this.portfolio = portfolio;
	}

	public Ministry(String portfolio) {
		super();
		this.portfolio = portfolio;
	}

	public Ministry() {

	}
}

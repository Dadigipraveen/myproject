package com.cg.nsa.entity;

public class Officer extends User {
	String name;
	String state;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public Officer(String name, String state) {
		super();
		this.name = name;
		this.state = state;
	}

	public Officer() {

	}
}

package com.cg.nsa.entity;

import java.time.LocalDate;

public class Scholarship {
	public Scholarship(int code, String category, String type, String name, String university, String address,
			String city, String state, String yearopen, String telephone, String principal, String status) {
		// TODO Auto-generated constructor stub
	}

	int scholarshipId;
	String scholarshipName; // Prime Minister Scholarship Scheme/SwarnaJayanti Fellowships Scheme, etc..
	String field; // Medical, Law, Engineering
	String course; // LLB, MBA, MBBS, BE, BTech, MTech, BCA
	int courseYear; // Current course year
	double sscScore;
	double hscScore;
	double familyIncome;
	String bankName;
	String bankIfsc;
	String accountNo;
	Student student;
	Institution institute;
	String appStatus; // Pending/Approved/Rejected
	String approval; // Pending/Granted

	public int getScholarshipId() {
		return scholarshipId;
	}

	public void setScholarshipId(int scholarshipId) {
		this.scholarshipId = scholarshipId;
	}

	public String getScholarshipName() {
		return scholarshipName;
	}

	public void setScholarshipName(String scholarshipName) {
		this.scholarshipName = scholarshipName;
	}

	public String getField() {
		return field;
	}

	public void setField(String field) {
		this.field = field;
	}

	public String getCourse() {
		return course;
	}

	public void setCourse(String course) {
		this.course = course;
	}

	public int getCourseYear() {
		return courseYear;
	}

	public void setCourseYear(int courseYear) {
		this.courseYear = courseYear;
	}

	public double getSscScore() {
		return sscScore;
	}

	public void setSscScore(double sscScore) {
		this.sscScore = sscScore;
	}

	public double getHscScore() {
		return hscScore;
	}

	public void setHscScore(double hscScore) {
		this.hscScore = hscScore;
	}

	public double getFamilyIncome() {
		return familyIncome;
	}

	public void setFamilyIncome(double familyIncome) {
		this.familyIncome = familyIncome;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getBankIfsc() {
		return bankIfsc;
	}

	public void setBankIfsc(String bankIfsc) {
		this.bankIfsc = bankIfsc;
	}

	public String getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

	public Institution getInstitute() {
		return institute;
	}

	public void setInstitute(Institution institute) {
		this.institute = institute;
	}

	public String getAppStatus() {
		return appStatus;
	}

	public void setAppStatus(String appStatus) {
		this.appStatus = appStatus;
	}

	public String getApproval() {
		return approval;
	}

	public void setApproval(String approval) {
		this.approval = approval;
	}

	public Scholarship(int scholarshipId, String scholarshipName, String field, String course, int courseYear,
			double sscScore, double hscScore, double familyIncome, String bankName, String bankIfsc, String accountNo,
			Student student, Institution institute, String appStatus, String approval) {
		super();
		this.scholarshipId = scholarshipId;
		this.scholarshipName = scholarshipName;
		this.field = field;
		this.course = course;
		this.courseYear = courseYear;
		this.sscScore = sscScore;
		this.hscScore = hscScore;
		this.familyIncome = familyIncome;
		this.bankName = bankName;
		this.bankIfsc = bankIfsc;
		this.accountNo = accountNo;
		this.student = student;
		this.institute = institute;
		this.appStatus = appStatus;
		this.approval = approval;
	}

	public Scholarship(int studentId, String fullName, String birthdate, String gender, String address, String email, long mobileNo) {

	}
}
